$("document").ready(function(){
	$(".nav > li").hover(function(){
		$(this).addClass("on");
	    $(this).children("div").stop(true,true).slideDown("fast");
	},function(){
	    $(this).removeClass("on");
		$(this).children("div").stop(true,true).slideUp("fast");
	})
    $("#navChild a:last-child ").css("border-bottom","none") 
    
    dingwei();
    
	var pgname = document.location.href;
		  pgname=pgname.replace(/\?.*$/,'')
		  pgname=pgname.replace(/^.*\//,'')
	if(pgname=="index.php"||pgname=="index.php#"||pgname==null||pgname==""){
		$(".banner").css("height","300px");
		$(".bann").css("height","300px");
		$("#focus").css("height","300px");
		$("#focus ul").css("height","300px");
		$("#focus ul li").css("height","300px");
	}
  
  var colorList,length,i;
  colorList = ['#606060','#787878','#8c8c8c','#9d9d9d','#b4b4b4'];
  length = $(".claListUlList li").length;
  for(i=0;i<length;i++){
     $(".claListUlList li").eq(i).find("a").css("background",colorList[i]);	
  }
  
  $(".casePicUl li").hover(function(){
  	$(this).find(".more a").css({"color":"#b02a28","background":"#ffffff"})
  },function(){
  		$(this).find(".more a").css({"color":"#ffffff","background":"#a9a9a9"})
  })
  
  $(".knowListUl li:last-child").css("border-bottom","none")
  
  $(".proListPic ul li:nth-child(4n)").css("margin-right","0px");   
  $(".proListPic ul li").hover(function(){
  	 var $abc = $(this);
  	 $abc.find(".title").stop(true,true).slideUp("fast",function(){$abc.find(".intro").slideDown("fast");})  
  },function(){
  	 var $abc = $(this);
  	 $abc.find(".title").stop(true,true);
     $abc.find(".intro").stop(true,true).slideUp("fast",function(){$abc.find(".title").slideDown("fast");})
  })
  
    	
  $(".contact dl:nth-child(2) dt").css("background","url(/templets/yiming/images/mobile.png) 14px 6px no-repeat");
  $(".contact dl:nth-child(3) dt").css("background","url(/templets/yiming/images/tel.png) 10px 4px no-repeat");
  $(".contact dl:nth-child(4) dt").css("background","url(/templets/yiming/images/mail.png) 10px 8px no-repeat");
  $(".contact dl:nth-child(5) dt").css("background","url(/templets/yiming/images/address.png) 12px 4px no-repeat");
  

  $(".footContactnr dl:nth-child(2) dt").css("background","url(/templets/yiming/images/mobile.png) 14px 6px no-repeat");
  $(".footContactnr dl:nth-child(3) dt").css("background","url(/templets/yiming/images/tel.png) 10px 4px no-repeat");
  $(".footContactnr dl:nth-child(4) dt").css("background","url(/templets/yiming/images/mail.png) 10px 8px no-repeat");
  $(".footContactnr dl:nth-child(5) dt").css("background","url(/templets/yiming/images/address.png) 12px 4px no-repeat");
	

  $(".shareDiv").hover(function(){
	 $(".shareList").css("display","block");	
  },function(){
	 $(".shareList").css("display","none");	
  })
  
  $(".share .qq").hover(function(){
  	$(this).css("background","url(/templets/yiming/images/qq2.png) left top no-repeat");
  },function(){
  	$(this).css("background","url(/templets/yiming/images/qq.png) left top no-repeat");
  });
  $(".share .qq2").hover(function(){
  	$(this).css("background","url(/templets/yiming/images/share2.png) left top no-repeat");
  },function(){
  	$(this).css("background","url(/templets/yiming/images/share.png) left top no-repeat");
  });
  $(".site").hover(function(){
  	$(this).css("background","url(/templets/yiming/images/site2.png) left top no-repeat");
  },function(){
  	$(this).css("background","url(/templets/yiming/images/site.png) left top no-repeat");
  });
  
  
   $('.backTop').click(function(){
		$('body,html').animate({scrollTop:0},500)
	});
   $('.codepic').hover(function(){$('.code').fadeIn()},function(){$('.code').fadeOut()});
	$('.backup').click(function(){
		$('body,html').animate({scrollTop:0},500)
	});
	$(".backup").hide();
	$(function() {
		$(window).scroll(function(){
			if ($(window).scrollTop()>500){
				$(".backup").fadeIn(1000);
			}else{
				$(".backup").fadeOut(1000);
			}
		});
	});
	
	$(".serviceTel .close").click(function(){
		$(".serviceTel").css("display","none");
	})
/* end index  jq  */
   
   $(".leftProClaListUl > li:last-child").css("border-bottom","none");
   $(".leftProClaListUl > li").click(function(){
   		$(this).next("ul").slideToggle();
   })
   
  $(".leftContact dl:nth-child(3) dt").css("background","url(/templets/yiming/images/mobile.png) 4px 6px no-repeat");
  $(".leftContact dl:nth-child(4) dt").css("background","url(/templets/yiming/images/tel.png) 2px 4px no-repeat");
  $(".leftContact dl:nth-child(5) dt").css("background","url(/templets/yiming/images/mail.png) left 8px no-repeat");
  $(".leftContact dl:nth-child(6) dt").css("background","url(/templets/yiming/images/address.png) 2px 4px no-repeat");
  
  $(".leftNewsUl li:last-child").css("border-bottom","none");
   
   
   
 	
   $(".mainConList .pic11:nth-child(3n)").css("margin-right","0px");  
   
    $(".mainConList .pic11").hover(function(){
	  	 var $abc = $(this);
	  	 $abc.find(".title").stop(true,true).slideUp("fast",function(){$abc.find(".intro").slideDown("fast");})  
	},function(){
	  	 var $abc = $(this);
	  	 $abc.find(".title").stop(true,true);
	     $abc.find(".intro").stop(true,true).slideUp("fast",function(){$abc.find(".title").slideDown("fast");})
	})
    
    

   $(".pic2:last-child a").css("border-bottom","none");
   $(".mainConList ul li:last-child").css("border-bottom","none");


   $(".pglist ul li").not(".on").hover(function(){ $(this).addClass("on");},function(){$(this).removeClass("on");})
   $(".mainContect .pgfyl p:first-child").css("border-left","none");
  
});



$("document").ready(function(){
	//case
	var page=1;
	var i=1;
	var box=$('.advPic ul');
	var n=$('.advPic li').length;
	var h=$('.advPic li').width();
	var pagetotal=Math.ceil(n/i);
	$('.picleft').bind('click',upwardsfn);
	$('.picright').bind('click',downfn);	
	function upwardsfn(){
		if(page>1){
			box.animate({ marginLeft : '+='+h }, "slow");
			page--;
			$(".picright").find("img").attr('src','/templets/yiming/images/advrightb.png');	
			if(page<=1){
				$('.picleft').find("img").attr('src','/templets/yiming/images/advleftw.png');
			}else{
				$('.picleft').find("img").attr('display','/templets/yiming/images/advleftb.png');	
			}
		}
	}
	function downfn(){
		if(pagetotal>page){
			box.animate({ marginLeft : '-='+h }, "slow");
			page++;
			$(".picleft").find("img").attr('src','/templets/yiming/images/advleftb.png');	
			if(page>=pagetotal){
				$('.picright').find("img").attr('src','/templets/yiming/images/advrightw.png');
			}else{
				$('.picright').find("img").attr('src','/templets/yiming/images/advrightb.png');	
			}
		}
	}

});


//导航定位
function dingwei(){
	var nav = document.getElementById("nav"); 
	var links = nav.getElementsByTagName("li"); 
	var lilen =$("#nav").find("li");
	
	var st2=new Array();
	var str1=new Array();
	var urrenturl = document.location.href; 	
	  urrenturl = urrenturl.replace("http://","");
	  urrenturlArr = urrenturl.split("/");
	  name = urrenturlArr[urrenturlArr.length-1];
	  st2 = name.split("_");
	var last = 0; 
	for (var i=0;i<links.length;i++) 
	{ 
	    linkurl =  lilen[i].getAttribute("rel"); 
		str1 = linkurl.split("/");
		var length2 = str1.length-1;
		str11 = str1[length2].split(".");
		 if(st2[0].indexOf(str11[0])!=-1) 
			{ 
			 last = i; 
			}
	} 
	links[last].className = "menu";
}
function scrolling(a,b,c){
	var speedp=30;
	var tabp=document.getElementById(a);
	var tab1p=document.getElementById(b);
	var tab2p=document.getElementById(c);
	tab2p.innerHTML=tab1p.innerHTML;
	function Marqueep(){
	if(tab2p.offsetWidth-tabp.scrollLeft<=0)
	tabp.scrollLeft-=tab1p.offsetWidth
	else{
	tabp.scrollLeft++;
	}
	}
	var MyMarp=setInterval(Marqueep,speedp);
	tabp.onmouseover=function() {clearInterval(MyMarp)};
	tabp.onmouseout=function() {MyMarp=setInterval(Marqueep,speedp)};
}

function upscrolling(){
	var speed=40;
	sdemo2.innerHTML = sdemo1.innerHTML;
	function Marquee(){
		if(sdemo2.offsetHeight - sdemo.scrollTop <= 0) {
			sdemo.scrollTop -= sdemo1.offsetHeight;
		} else{
			sdemo.scrollTop++;
		}
	}
	var MyMar = setInterval(Marquee,speed);
	sdemo.onmouseover = function(){ clearInterval(MyMar); }
	sdemo.onmouseout = function(){ MyMar=setInterval(Marquee,speed) }
}