$("document").ready(function(){
	/***不需要自动滚动，去掉即可***/
	var time = window.setInterval(function(){
		$('.caseRight').click();	
	},5000);
	$('.casePicUlIdBox').mouseover(function() {
			clearInterval(time);
		});
	$('.casePicUlIdBox').mouseout(function(){
		  time = window.setInterval(function(){
			$('.caseRight').click();	
		 },5000);
	});
	
	$('.caseLeft').mouseover(function() {
			clearInterval(time);
		});
	$('.caseLeft').mouseout(function(){
		  time = window.setInterval(function(){
			$('.caseLeft').click();	
		 },5000);
	});
	
	$('.caseRight').mouseover(function() {
			clearInterval(time);
		});
	$('.caseRight').mouseout(function(){
		  time = window.setInterval(function(){
			$('.caseRight').click();	
		 },5000);
	});
	/***不需要自动滚动，去掉即可***/
	var page=1;
	var i=1;
	var box=$('.casePicUlIdBox');
	var h=$('.casePicUlIdBox ul').width();
	var pagetotal= $('.casePicUlIdBox ul').length;
	$(".casePicUlIdBox").css("width",pagetotal*h+"px");
	$('.htmlpic2').html($('.htmlpic1').html());//复制内容
   // document.getElementById("a").innerHTML =  document.getElementById("b").innerHTML;
    w = pagetotal*1000;	
    //alert(w);
	$('.caseLeft').bind('click',upwardsfn);
	$('.caseRight').bind('click',downfn);	
	function upwardsfn(){
		/*
		if($('.htmlpic1,.htmlpic2').is(':animated')){
			$('.htmlpic1,.htmlpic2').stop(true,true);
		}*/
		/*if(page>1){
			box.animate({ marginLeft : '+='+h }, "slow");
			page--;
		}*/
		if($('.htmlpic2,.htmlpic1').is(':animated')){
			$('.htmlpic2,.htmlpic1').stop(true,true);
		}
		if($('.casePicUlIdBox ul').length>1){
			ml = parseInt($('.htmlpic1').css('left'));
			sl = parseInt($('.htmlpic2').css('left'));
		   // alert(ml);
			if(ml<=0 && ml>w*-1){
				if(ml==0){
					$('.htmlpic2').css({left: w * -1 + 'px'});
					sl = parseInt($('.htmlpic2').css('left'));
				}
				$('.htmlpic2').animate({left: sl + 250 + 'px'},'slow');
				$('.htmlpic1').animate({left: ml + 250 + 'px'},'slow');				
			}else{
				if(sl==0){
					$('.htmlpic1').css({left: w * -1 + 'px'});
					ml = parseInt($('.htmlpic1').css('left'));
				}
				$('.htmlpic1').animate({left: ml + 250 + 'px'},'slow');			
				$('.htmlpic2').animate({left: sl + 250 + 'px'},'slow');
			}
		}
	}
	function downfn(){
		/*f(pagetotal>page){
			box.animate({ marginLeft : '-='+h }, "slow");
			page++;
		}*/
		//alert(w);
		if($('.htmlpic1,.htmlpic2').is(':animated')){
			$('.htmlpic1,.htmlpic2').stop(true,true);
		}
		if($('.casePicUlIdBox ul').length>1){//多于4张图片
			ml = parseInt($('.htmlpic1').css('left'));//默认图片ul位置
			sl = parseInt($('.htmlpic2').css('left'));//交换图片ul位置
			if(ml<= 1000 && ml>w*-1){//默认图片显示时
			    if(ml+w == 1000){//交换图片最后一屏时
					$('.htmlpic2').css({left:'1000px'})//默认图片放在显示区域右
					sl = parseInt($('.htmlpic2').css('left'));
				}
				$('.htmlpic1').animate({left: ml - 250 + 'px'},'slow');//默认图片滚动	
				$('.htmlpic2').animate({left: sl - 250 + 'px'},'slow');//交换图片滚动
			}else{//交换图片显示时

				if(sl+w == 1000){//交换图片最后一屏时
					$('.htmlpic1').css({left:'1000px'})//默认图片放在显示区域右
					ml = parseInt($('.htmlpic1').css('left'));
				}
				$('.htmlpic1').animate({left: ml - 250 + 'px'},'slow');//默认图片滚动	
				$('.htmlpic2').animate({left: sl - 250 + 'px'},'slow');//交换图片滚动
			}
		}

	}

});